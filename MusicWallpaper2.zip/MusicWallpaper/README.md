# Music Wallpaper (Android live wallpaper)

Shows what you're playing as a live wallpaper: drifting, blurred album-color blobs in the
background (ported from your YouTube Music TV Mode script) with the album cover and title at the
bottom. Works with any app that publishes a media session (YouTube Music, Spotify, etc).

## Build
1. Open this folder in Android Studio (Ladybug or newer). Let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s).
3. Open the app, then:
   - Tap **Grant notification access** and enable Music Wallpaper. This lets Android share the
     now-playing info with the app. Notifications are not read.
   - Tap **Set as live wallpaper** and apply it to the lock screen (or home + lock).
   - Pick your default and home wallpapers, blur strength and when music should show.

## How the switching works
- Music is shown only while something plays (or is paused, if "Keep showing the cover while paused" is on).
- "Lock screen only": cover shows on the lock screen, unlocking fades to the blurred home wallpaper.
- "Lock screen and home screen": cover stays up on both while music plays.
- "Wait before switching back": delay in seconds before fading to the regular wallpaper.
- Lock screen without music: default wallpaper, sharp. Home screen: home wallpaper (or the default), blurred.

## Files
- `MusicWallpaperService.kt` – the wallpaper engine, blob background, cover, switching logic
- `MusicListenerService.kt` – reads title / artist / cover art from the active media session
- `PaletteExtractor.kt` – color extraction, same algorithm as the userscript
- `BlurUtil.kt`, `ImageStore.kt` – home wallpaper blur and image storage
- `SettingsActivity.kt`, `Prefs.kt` – settings screen and saved values

## No Android Studio? Build the APK on GitHub (works from a phone browser)
1. Create a free GitHub account and a new empty repository.
2. Upload the contents of this folder (unzipped) to it, keeping the `.github` folder.
3. Open the repo's **Actions** tab, pick **Build APK**, and wait for it to finish.
4. Open the finished run, download the **MusicWallpaper-apk** artifact, unzip it and install the APK.
