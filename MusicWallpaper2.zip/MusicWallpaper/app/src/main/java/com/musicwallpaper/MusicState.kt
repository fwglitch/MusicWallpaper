package com.musicwallpaper

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

/** Shared "now playing" snapshot. The listener service writes it, the wallpaper engine reads it. */
object MusicState {

    fun interface Listener {
        fun onMusicChanged()
    }

    @Volatile var title: String = ""
        private set
    @Volatile var artist: String = ""
        private set
    @Volatile var art: Bitmap? = null
        private set
    @Volatile var isPlaying: Boolean = false
        private set

    val hasTrack: Boolean
        get() = title.isNotBlank() || art != null

    private val listeners = CopyOnWriteArraySet<Listener>()
    private val main = Handler(Looper.getMainLooper())

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    fun update(title: String, artist: String, art: Bitmap?, playing: Boolean) {
        this.title = title
        this.artist = artist
        this.art = art
        this.isPlaying = playing
        main.post { for (l in listeners) l.onMusicChanged() }
    }

    fun clear() = update("", "", null, false)
}
