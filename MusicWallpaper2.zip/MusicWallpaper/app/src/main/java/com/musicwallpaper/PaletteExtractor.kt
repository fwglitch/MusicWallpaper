package com.musicwallpaper

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Kotlin port of the extractPalette / vividize logic from the TV Mode userscript. */
object PaletteExtractor {

    const val SIZE = 8

    val DEFAULT = intArrayOf(
        0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(), 0xFFF97316.toInt(), 0xFF22D3EE.toInt(),
        0xFF4ADE80.toInt(), 0xFFFACC15.toInt(), 0xFFEF4444.toInt(), 0xFF3B82F6.toInt()
    )

    fun extract(src: Bitmap): IntArray? {
        return try {
            val soft = if (src.config == Bitmap.Config.HARDWARE) {
                src.copy(Bitmap.Config.ARGB_8888, false) ?: return null
            } else src
            val n = 64
            val small = Bitmap.createScaledBitmap(soft, n, n, true)
            val px = IntArray(n * n)
            small.getPixels(px, 0, n, 0, 0, n, n)

            // key -> [sumR, sumG, sumB, count]
            val buckets = HashMap<Int, DoubleArray>()
            for (p in px) {
                if ((p ushr 24) < 128) continue
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                val key = (((r + 8) / 16) shl 10) or (((g + 8) / 16) shl 5) or ((b + 8) / 16)
                val arr = buckets.getOrPut(key) { DoubleArray(4) }
                arr[0] += r.toDouble(); arr[1] += g.toDouble(); arr[2] += b.toDouble(); arr[3] += 1.0
            }
            if (buckets.isEmpty()) return null

            val sorted = buckets.values.sortedByDescending { it[3] }
            val diverse = selectDiverse(sorted, SIZE)
            val palette = diverse.map { vividize(it[0].roundToInt(), it[1].roundToInt(), it[2].roundToInt()) }
                .toMutableList()
            while (palette.isNotEmpty() && palette.size < SIZE) palette.add(palette.last())
            if (palette.size == SIZE) palette.toIntArray() else null
        } catch (e: Exception) {
            null
        }
    }

    private fun distance(a: DoubleArray, b: DoubleArray): Double {
        val dr = a[0] - b[0]
        val dg = a[1] - b[1]
        val db = a[2] - b[2]
        return sqrt(2 * dr * dr + 4 * dg * dg + 3 * db * db)
    }

    private fun selectDiverse(sorted: List<DoubleArray>, count: Int): List<DoubleArray> {
        val picked = ArrayList<DoubleArray>()
        var minDist = 90
        while (picked.size < count && minDist >= 0) {
            for (bucket in sorted) {
                if (picked.size >= count) break
                val c = bucket[3]
                val rgb = doubleArrayOf(bucket[0] / c, bucket[1] / c, bucket[2] / c)
                if (picked.all { distance(it, rgb) >= minDist }) picked.add(rgb)
            }
            minDist -= 15
        }
        return picked
    }

    private fun vividize(r: Int, g: Int, b: Int): Int {
        val hsl = rgbToHsl(r, g, b)
        val s = min(1.0, hsl[1] * 1.45)
        val l = min(0.8, max(0.18, hsl[2]))
        val rgb = hslToRgb(hsl[0], s, l)
        return (0xFF shl 24) or (rgb[0] shl 16) or (rgb[1] shl 8) or rgb[2]
    }

    private fun rgbToHsl(r8: Int, g8: Int, b8: Int): DoubleArray {
        val r = r8 / 255.0
        val g = g8 / 255.0
        val b = b8 / 255.0
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        var h: Double
        val s: Double
        val l = (mx + mn) / 2
        if (mx == mn) {
            h = 0.0
            s = 0.0
        } else {
            val d = mx - mn
            s = if (l > 0.5) d / (2 - mx - mn) else d / (mx + mn)
            h = when (mx) {
                r -> (g - b) / d + (if (g < b) 6 else 0)
                g -> (b - r) / d + 2
                else -> (r - g) / d + 4
            }
            h /= 6
        }
        return doubleArrayOf(h, s, l)
    }

    private fun hue2rgb(p: Double, q: Double, t0: Double): Double {
        var t = t0
        if (t < 0) t += 1
        if (t > 1) t -= 1
        if (t < 1.0 / 6) return p + (q - p) * 6 * t
        if (t < 1.0 / 2) return q
        if (t < 2.0 / 3) return p + (q - p) * (2.0 / 3 - t) * 6
        return p
    }

    private fun hslToRgb(h: Double, s: Double, l: Double): IntArray {
        val r: Double
        val g: Double
        val b: Double
        if (s == 0.0) {
            r = l; g = l; b = l
        } else {
            val q = if (l < 0.5) l * (1 + s) else l + s - l * s
            val p = 2 * l - q
            r = hue2rgb(p, q, h + 1.0 / 3)
            g = hue2rgb(p, q, h)
            b = hue2rgb(p, q, h - 1.0 / 3)
        }
        return intArrayOf((r * 255).roundToInt(), (g * 255).roundToInt(), (b * 255).roundToInt())
    }
}
