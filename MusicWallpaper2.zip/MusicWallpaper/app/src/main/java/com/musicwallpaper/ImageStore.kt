package com.musicwallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.InputStream
import kotlin.math.max

/** Stores the user's chosen wallpaper images inside the app (no storage permission needed). */
object ImageStore {

    const val DEFAULT_FILE = "default_wallpaper.jpg"
    const val HOME_FILE = "home_wallpaper.jpg"
    private const val MAX_SIDE = 2400

    fun exists(ctx: Context, name: String) = File(ctx.filesDir, name).exists()

    fun delete(ctx: Context, name: String) {
        File(ctx.filesDir, name).delete()
    }

    fun importFrom(ctx: Context, uri: Uri, name: String): Boolean {
        try {
            val resolver = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return false

            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false

            val rotation = resolver.openInputStream(uri)?.use { readRotation(it) } ?: 0
            if (rotation != 0) {
                val m = Matrix().apply { postRotate(rotation.toFloat()) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val longest = max(bmp.width, bmp.height)
            if (longest > MAX_SIDE) {
                val s = MAX_SIDE.toFloat() / longest
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            }
            File(ctx.filesDir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun readRotation(stream: InputStream): Int {
        return try {
            when (ExifInterface(stream).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) {
            0
        }
    }

    /** Loads the saved image, down-sampled so it is not much bigger than the screen. */
    fun load(ctx: Context, name: String, targetW: Int, targetH: Int): Bitmap? {
        val f = File(ctx.filesDir, name)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0) return null
        var sample = 1
        while (o.outWidth / (sample * 2) >= targetW && o.outHeight / (sample * 2) >= targetH) sample *= 2
        val d = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(f.path, d)
    }

    fun centerCrop(src: Bitmap, outW: Int, outH: Int): Bitmap {
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val s = max(outW.toFloat() / src.width, outH.toFloat() / src.height)
        val m = Matrix()
        m.setScale(s, s)
        m.postTranslate((outW - src.width * s) / 2f, (outH - src.height * s) / 2f)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }
}
