package com.musicwallpaper

import android.content.ComponentName
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import java.net.URL
import java.util.concurrent.Executors

/**
 * Needs "Notification access" (granted once in system settings). It does not read notifications;
 * Android only allows apps with this access to see other apps' media sessions (YouTube Music,
 * Spotify, etc.), which is where the title, artist and cover art come from.
 */
class MusicListenerService : NotificationListenerService() {

    private var sessionManager: MediaSessionManager? = null
    private val component by lazy { ComponentName(this, MusicListenerService::class.java) }
    private val attached = ArrayList<Pair<MediaController, MediaController.Callback>>()
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private var artKey = ""
    private var artBitmap: Bitmap? = null
    private var fetchingKey = ""

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> attach(list ?: emptyList()) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val m = getSystemService(MediaSessionManager::class.java)
        sessionManager = m
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, component)
            attach(m.getActiveSessions(component))
        } catch (_: SecurityException) {
            // Notification access was revoked.
        }
    }

    override fun onListenerDisconnected() {
        detachAll()
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        MusicState.clear()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    private fun detachAll() {
        for ((controller, cb) in attached) {
            try {
                controller.unregisterCallback(cb)
            } catch (_: Exception) {
            }
        }
        attached.clear()
    }

    private fun attach(controllers: List<MediaController>) {
        detachAll()
        for (c in controllers) {
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
                override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
                override fun onSessionDestroyed() = refresh()
            }
            try {
                c.registerCallback(cb)
                attached.add(c to cb)
            } catch (_: Exception) {
            }
        }
        refresh()
    }

    private fun isActive(c: MediaController): Boolean {
        val s = c.playbackState?.state
        return s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    private fun refresh() {
        val list = attached.map { it.first }
        val playing = list.firstOrNull { isActive(it) }
        val controller = playing ?: list.firstOrNull { it.metadata != null }
        if (controller == null) {
            artKey = ""
            artBitmap = null
            MusicState.clear()
            return
        }

        val md = controller.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val uri = firstUri(md)

        val key = "$title|$artist|$uri"
        if (key != artKey) {
            artKey = key
            artBitmap = null
        }
        // Apps often send the title first and the cover a moment later, so keep retrying.
        if (artBitmap == null && md != null) {
            artBitmap = bitmapFrom(md, uri)
            if (artBitmap == null && uri != null &&
                (uri.startsWith("http://") || uri.startsWith("https://")) && fetchingKey != key
            ) {
                fetchRemote(key, uri)
            }
        }

        MusicState.update(title, artist, artBitmap, playing != null)
    }

    private fun firstUri(md: MediaMetadata?): String? {
        if (md == null) return null
        val keys = listOf(
            MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
            MediaMetadata.METADATA_KEY_ART_URI,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI
        )
        for (k in keys) {
            val v = md.getString(k)
            if (!v.isNullOrBlank()) return v
        }
        return null
    }

    private fun bitmapFrom(md: MediaMetadata, uri: String?): Bitmap? {
        val bitmapKeys = listOf(
            MediaMetadata.METADATA_KEY_ALBUM_ART,
            MediaMetadata.METADATA_KEY_ART,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON
        )
        for (k in bitmapKeys) {
            md.getBitmap(k)?.let { return it }
        }
        if (uri != null && (uri.startsWith("content://") || uri.startsWith("file://"))) {
            try {
                contentResolver.openInputStream(Uri.parse(uri))?.use {
                    return BitmapFactory.decodeStream(it)
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun fetchRemote(key: String, url: String) {
        fetchingKey = key
        io.execute {
            val bmp = try {
                URL(url).openStream().use { BitmapFactory.decodeStream(it) }
            } catch (_: Exception) {
                null
            }
            main.post {
                if (bmp != null && key == artKey) {
                    artBitmap = bmp
                    refresh()
                }
            }
        }
    }
}
