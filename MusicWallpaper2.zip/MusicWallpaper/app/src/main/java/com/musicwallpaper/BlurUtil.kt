package com.musicwallpaper

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * Software blur used for the home screen wallpaper. The image is shrunk and box-blurred three
 * times (which approximates a gaussian). It is drawn stretched back up with bilinear filtering.
 * Works on every Android version and is computed once, not per frame.
 */
object BlurUtil {

    fun blur(src: Bitmap, pct: Int): Bitmap {
        if (pct <= 0) return src
        val longest = max(src.width, src.height)
        val target = (480f - 4.1f * pct).coerceAtLeast(70f)
        val scale = min(1f, target / longest)
        val sw = max(1, (src.width * scale).toInt())
        val sh = max(1, (src.height * scale).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, true).copy(Bitmap.Config.ARGB_8888, true)

        val radius = min(4 + (pct / 100f * 4f).toInt(), max(1, min(sw, sh) / 2 - 1))
        var a = IntArray(sw * sh)
        var b = IntArray(sw * sh)
        small.getPixels(a, 0, sw, 0, 0, sw, sh)
        repeat(3) {
            pass(a, b, lines = sh, n = sw, lineStride = sw, elemStride = 1, r = radius) // horizontal
            pass(b, a, lines = sw, n = sh, lineStride = 1, elemStride = sw, r = radius) // vertical
        }
        small.setPixels(a, 0, sw, 0, 0, sw, sh)
        return small
    }

    private fun pass(
        src: IntArray, dst: IntArray,
        lines: Int, n: Int, lineStride: Int, elemStride: Int, r: Int
    ) {
        val div = 2 * r + 1
        for (l in 0 until lines) {
            val base = l * lineStride
            var sa = 0
            var sr = 0
            var sg = 0
            var sb = 0
            for (k in -r..r) {
                val p = src[base + k.coerceIn(0, n - 1) * elemStride]
                sa += p ushr 24
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (i in 0 until n) {
                dst[base + i * elemStride] =
                    ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[base + min(i + r + 1, n - 1) * elemStride]
                val rem = src[base + max(i - r, 0) * elemStride]
                sa += (add ushr 24) - (rem ushr 24)
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }
}
