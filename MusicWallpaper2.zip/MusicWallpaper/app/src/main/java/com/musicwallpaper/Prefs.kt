package com.musicwallpaper

import android.content.Context
import android.content.SharedPreferences

/** All user settings live here. The wallpaper engine listens for changes and re-reads them. */
class Prefs(context: Context) {

    val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /** Album cover width as a percent of screen width. */
    var coverSizePct: Int
        get() = sp.getInt(K_COVER_SIZE, 72)
        set(v) = sp.edit().putInt(K_COVER_SIZE, v).apply()

    /** Gap between the bottom of the screen and the cover block, percent of screen height. */
    var coverBottomPct: Int
        get() = sp.getInt(K_COVER_BOTTOM, 12)
        set(v) = sp.edit().putInt(K_COVER_BOTTOM, v).apply()

    /** Corner radius as a percent of the cover size (50 = circle). */
    var cornerPct: Int
        get() = sp.getInt(K_CORNER, 8)
        set(v) = sp.edit().putInt(K_CORNER, v).apply()

    var showText: Boolean
        get() = sp.getBoolean(K_SHOW_TEXT, true)
        set(v) = sp.edit().putBoolean(K_SHOW_TEXT, v).apply()

    /** Dark overlay on top of the color blobs, percent. */
    var frostPct: Int
        get() = sp.getInt(K_FROST, 32)
        set(v) = sp.edit().putInt(K_FROST, v).apply()

    /** Blob movement speed, percent (100 = same as the original script). */
    var animSpeed: Int
        get() = sp.getInt(K_SPEED, 100)
        set(v) = sp.edit().putInt(K_SPEED, v).apply()

    /** MODE_LOCK_ONLY or MODE_LOCK_AND_HOME. */
    var switchMode: Int
        get() = sp.getInt(K_MODE, MODE_LOCK_ONLY)
        set(v) = sp.edit().putInt(K_MODE, v).apply()

    /** Seconds to keep the music wallpaper after the trigger ends (unlock, or music stops). */
    var switchDelaySec: Int
        get() = sp.getInt(K_DELAY, 0)
        set(v) = sp.edit().putInt(K_DELAY, v).apply()

    /** Keep showing the cover while a track is paused (instead of reverting right away). */
    var keepWhenPaused: Boolean
        get() = sp.getBoolean(K_KEEP_PAUSED, false)
        set(v) = sp.edit().putBoolean(K_KEEP_PAUSED, v).apply()

    /** Blur strength for the home screen wallpaper, percent. */
    var homeBlurPct: Int
        get() = sp.getInt(K_HOME_BLUR, 60)
        set(v) = sp.edit().putInt(K_HOME_BLUR, v).apply()

    /** Changing this value tells the engine to reload the wallpaper image files. */
    fun bumpImageVersion() {
        sp.edit().putLong(K_IMAGE_VERSION, System.nanoTime()).apply()
    }

    companion object {
        const val NAME = "music_wallpaper_prefs"

        const val K_COVER_SIZE = "cover_size"
        const val K_COVER_BOTTOM = "cover_bottom"
        const val K_CORNER = "corner"
        const val K_SHOW_TEXT = "show_text"
        const val K_FROST = "frost"
        const val K_SPEED = "speed"
        const val K_MODE = "mode"
        const val K_DELAY = "delay"
        const val K_KEEP_PAUSED = "keep_paused"
        const val K_HOME_BLUR = "home_blur"
        const val K_IMAGE_VERSION = "image_version"

        const val MODE_LOCK_ONLY = 0
        const val MODE_LOCK_AND_HOME = 1
    }
}
