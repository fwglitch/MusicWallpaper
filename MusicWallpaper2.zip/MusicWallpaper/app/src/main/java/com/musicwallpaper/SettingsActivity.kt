package com.musicwallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var accessStatus: TextView
    private lateinit var defaultStatus: TextView
    private lateinit var homeStatus: TextView

    private val bg = Color.parseColor("#0E0E14")
    private val accent = Color.parseColor("#B79CFF")
    private val dim = Color.parseColor("#9A9AAE")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(48))
        }
        scroll.addView(root)
        setContentView(scroll)
        build(root)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ------------------------------------------------------------------ UI

    private fun build(root: LinearLayout) {
        root.addView(TextView(this).apply {
            text = "Music Wallpaper"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })

        // 1. Setup
        header(root, "Setup")
        accessStatus = note(root, "")
        button(root, "1. Grant notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        note(root, "Needed so Android lets this app see what is playing (YouTube Music, Spotify...). Notifications are never read or stored.")
        button(root, "2. Set as live wallpaper") { openWallpaperPicker() }
        note(root, "When Android asks where to apply it, choose \"Lock screen\" or \"Home and lock screen\".")

        // 2. Music look
        header(root, "Music display")
        slider(root, "Album cover size", 30, 95, "%", prefs.coverSizePct) { prefs.coverSizePct = it }
        slider(root, "Distance from bottom", 0, 40, "%", prefs.coverBottomPct) { prefs.coverBottomPct = it }
        slider(root, "Corner roundness", 0, 50, "%", prefs.cornerPct) { prefs.cornerPct = it }
        slider(root, "Background darkening", 0, 70, "%", prefs.frostPct) { prefs.frostPct = it }
        slider(root, "Blob movement speed", 20, 200, "%", prefs.animSpeed) { prefs.animSpeed = it }
        toggle(root, "Show song title and artist", prefs.showText) { prefs.showText = it }

        // 3. When to switch
        header(root, "When to show music")
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val rLock = radio("Lock screen only", 101)
        val rBoth = radio("Lock screen and home screen", 102)
        group.addView(rLock)
        group.addView(rBoth)
        group.check(if (prefs.switchMode == Prefs.MODE_LOCK_AND_HOME) 102 else 101)
        group.setOnCheckedChangeListener { _, id ->
            prefs.switchMode = if (id == 102) Prefs.MODE_LOCK_AND_HOME else Prefs.MODE_LOCK_ONLY
        }
        root.addView(group)
        note(root, "The music wallpaper only appears while a song is playing. Otherwise your regular wallpapers are used.")
        slider(root, "Wait before switching back", 0, 60, " s", prefs.switchDelaySec) { prefs.switchDelaySec = it }
        note(root, "How long the music wallpaper stays after you unlock (lock-only mode) or after the music stops.")
        toggle(root, "Keep showing the cover while paused", prefs.keepWhenPaused) { prefs.keepWhenPaused = it }

        // 4. Regular wallpapers
        header(root, "Regular wallpapers")
        root.addView(label("Default wallpaper (lock screen, no music)"))
        defaultStatus = note(root, "")
        row(root,
            "Choose image" to { pickImage(REQ_DEFAULT) },
            "Remove" to { removeImage(ImageStore.DEFAULT_FILE) })

        root.addView(label("Home screen wallpaper"))
        homeStatus = note(root, "")
        row(root,
            "Choose image" to { pickImage(REQ_HOME) },
            "Remove" to { removeImage(ImageStore.HOME_FILE) })
        note(root, "If no home image is set, the default wallpaper is used and blurred.")
        slider(root, "Home screen blur", 0, 100, "%", prefs.homeBlurPct) { prefs.homeBlurPct = it }
    }

    private fun refreshStatus() {
        accessStatus.text = if (hasListenerAccess()) {
            "✓ Notification access granted"
        } else {
            "✗ Notification access not granted yet"
        }
        accessStatus.setTextColor(if (hasListenerAccess()) Color.parseColor("#7DDC8B") else Color.parseColor("#FF8A80"))
        defaultStatus.text = if (ImageStore.exists(this, ImageStore.DEFAULT_FILE)) "Image set" else "Not set (dark gradient)"
        homeStatus.text = if (ImageStore.exists(this, ImageStore.HOME_FILE)) "Image set" else "Not set (uses default)"
    }

    // ------------------------------------------------------------------ actions

    private fun hasListenerAccess(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun openWallpaperPicker() {
        try {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this, MusicWallpaperService::class.java)
                )
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Toast.makeText(this, "Open Wallpaper settings and pick Music Wallpaper", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(i, req)
    }

    private fun removeImage(name: String) {
        ImageStore.delete(this, name)
        prefs.bumpImageVersion()
        refreshStatus()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val name = if (requestCode == REQ_DEFAULT) ImageStore.DEFAULT_FILE else ImageStore.HOME_FILE
        Thread {
            val ok = ImageStore.importFrom(applicationContext, uri, name)
            runOnUiThread {
                if (ok) prefs.bumpImageVersion()
                else Toast.makeText(this, "Could not load that image", Toast.LENGTH_SHORT).show()
                refreshStatus()
            }
        }.start()
    }

    // ------------------------------------------------------------------ view helpers

    private fun header(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text.uppercase()
            textSize = 13f
            letterSpacing = 0.08f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            setPadding(0, dp(30), 0, dp(8))
        })
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.WHITE)
        setPadding(0, dp(14), 0, 0)
    }

    private fun note(parent: LinearLayout, text: String): TextView {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(dim)
            setPadding(0, dp(4), 0, dp(4))
        }
        parent.addView(tv)
        return tv
    }

    private fun radio(text: String, viewId: Int) = RadioButton(this).apply {
        this.text = text
        id = viewId
        setTextColor(Color.WHITE)
    }

    private fun button(parent: LinearLayout, text: String, onClick: () -> Unit) {
        parent.addView(Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun row(parent: LinearLayout, vararg items: Pair<String, () -> Unit>) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((text, action) in items) {
            r.addView(Button(this).apply {
                this.text = text
                isAllCaps = false
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        parent.addView(r)
    }

    private fun toggle(parent: LinearLayout, text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        parent.addView(Switch(this).apply {
            this.text = text
            isChecked = checked
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(0, dp(14), 0, dp(6))
            setOnCheckedChangeListener { _, value -> onChange(value) }
        })
    }

    private fun slider(
        parent: LinearLayout, label: String, lo: Int, hi: Int, unit: String,
        initial: Int, onCommit: (Int) -> Unit
    ) {
        val title = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, 0)
        }
        fun setLabel(v: Int) {
            title.text = "$label: $v$unit"
        }
        setLabel(initial)

        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = (initial - lo).coerceIn(0, hi - lo)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            private var tracking = false
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                setLabel(progress + lo)
                if (fromUser && !tracking) onCommit(progress + lo)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                tracking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                tracking = false
                onCommit(seekBar.progress + lo)
            }
        })
        parent.addView(title)
        parent.addView(bar)
    }

    companion object {
        private const val REQ_DEFAULT = 1
        private const val REQ_HOME = 2
    }
}
