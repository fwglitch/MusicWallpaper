package com.musicwallpaper

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.text.TextPaint
import android.text.TextUtils
import android.view.SurfaceHolder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Live wallpaper with three layers, drawn back to front:
 *  1. default wallpaper (shown on the lock screen when no music is active)
 *  2. blurred home wallpaper (fades in when the phone is unlocked)
 *  3. music scene: drifting album-color blobs, dark frost, cover art + title at the bottom
 *
 * The music layer fades in/out depending on the "when to show music" settings.
 */
class MusicWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = MusicEngine()

    private class CoverLayer(val bmp: Bitmap) {
        val shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    }

    inner class MusicEngine : Engine(), MusicState.Listener,
        SharedPreferences.OnSharedPreferenceChangeListener {

        private val svc: Context get() = this@MusicWallpaperService
        private val prefs = Prefs(this@MusicWallpaperService)
        private val handler = Handler(Looper.getMainLooper())
        private val keyguard: KeyguardManager? = getSystemService(KeyguardManager::class.java)
        private val startTime = SystemClock.uptimeMillis()

        private var visible = false
        private var w = 0
        private var h = 0

        // ---- cached settings ----
        private var coverSizePct = 72
        private var coverBottomPct = 12
        private var cornerPct = 8
        private var showText = true
        private var frostPct = 32
        private var animSpeed = 100
        private var switchMode = Prefs.MODE_LOCK_ONLY
        private var switchDelayMs = 0L
        private var keepPaused = false
        private var homeBlurPct = 60

        // ---- images ----
        private var defBmp: Bitmap? = null
        private var homeBlurBmp: Bitmap? = null

        // ---- music visuals ----
        private var palFrom = PaletteExtractor.DEFAULT.copyOf()
        private var palTo = PaletteExtractor.DEFAULT.copyOf()
        private var palStart = 0L
        private val palCur = IntArray(PaletteExtractor.SIZE)
        private var lastArt: Bitmap? = null
        private var curCover: CoverLayer? = null
        private var prevCover: CoverLayer? = null
        private var coverStart = -10_000L
        private var shownTitle = ""
        private var shownArtist = ""

        // ---- scene state ----
        private var locked = false
        private var lastLockCheck = 0L
        private var musicAlpha = 0f
        private var homeAlpha = 0f
        private var musicHoldUntil = 0L
        private var lastFrame = 0L
        private var animating = false

        // ---- paints / scratch objects ----
        private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        private val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val bgPaint = Paint()
        private val dimPaint = Paint()
        private val coverPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        private val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        private val artistPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(200, 255, 255, 255)
            textAlign = Paint.Align.CENTER
        }
        private val notePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(160, 255, 255, 255)
            textAlign = Paint.Align.CENTER
        }
        private val blobBmp = makeBlobBitmap()
        private val shaderMatrix = Matrix()
        private val dstRect = RectF()
        private val coverRect = RectF()
        private val shadowRect = RectF()

        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                lastLockCheck = 0L
                if (visible) drawFrame()
            }
        }

        private val ticker = object : Runnable {
            override fun run() {
                if (!visible) return
                drawFrame()
                handler.postDelayed(this, if (animating) 33L else 250L)
            }
        }

        // ------------------------------------------------------------------ lifecycle

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            loadPrefs()
            prefs.sp.registerOnSharedPreferenceChangeListener(this)
            MusicState.addListener(this)
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(receiver, filter)
            }
            syncMusicVisuals()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (width != w || height != h) {
                w = width
                h = height
                bgPaint.shader = LinearGradient(
                    0f, 0f, 0f, h.toFloat(),
                    0xFF22223A.toInt(), 0xFF08080D.toInt(), Shader.TileMode.CLAMP
                )
                rebuildImages()
            }
            drawFrame()
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            drawFrame()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(ticker)
            if (visible) {
                lastLockCheck = 0L
                lastFrame = SystemClock.uptimeMillis()
                handler.post(ticker)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(ticker)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(ticker)
            prefs.sp.unregisterOnSharedPreferenceChangeListener(this)
            MusicState.removeListener(this)
            try {
                unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
            super.onDestroy()
        }

        // ------------------------------------------------------------------ settings / state

        private fun loadPrefs() {
            coverSizePct = prefs.coverSizePct
            coverBottomPct = prefs.coverBottomPct
            cornerPct = prefs.cornerPct
            showText = prefs.showText
            frostPct = prefs.frostPct
            animSpeed = prefs.animSpeed
            switchMode = prefs.switchMode
            switchDelayMs = prefs.switchDelaySec * 1000L
            keepPaused = prefs.keepWhenPaused
            homeBlurPct = prefs.homeBlurPct
        }

        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            loadPrefs()
            if (key == Prefs.K_HOME_BLUR || key == Prefs.K_IMAGE_VERSION) rebuildImages()
            if (visible) drawFrame()
        }

        override fun onMusicChanged() {
            syncMusicVisuals()
            if (visible) drawFrame()
        }

        private fun rebuildImages() {
            if (w == 0 || h == 0) return
            val def = ImageStore.load(svc, ImageStore.DEFAULT_FILE, w, h)
            defBmp = def?.let { ImageStore.centerCrop(it, w, h) }
            val home = ImageStore.load(svc, ImageStore.HOME_FILE, w, h) ?: def
            homeBlurBmp = home?.let {
                val s = min(1f, 960f / max(w, h))
                val cropped = ImageStore.centerCrop(it, max(1, (w * s).toInt()), max(1, (h * s).toInt()))
                BlurUtil.blur(cropped, homeBlurPct)
            }
        }

        private fun syncMusicVisuals() {
            if (!MusicState.hasTrack && !isPreview) return // keep last visuals so fade-out looks right
            val now = SystemClock.uptimeMillis()
            val art = MusicState.art
            if (art !== lastArt) {
                lastArt = art
                prevCover = curCover
                curCover = art?.let { CoverLayer(it) }
                coverStart = now
                val newPal = art?.let { PaletteExtractor.extract(it) } ?: PaletteExtractor.DEFAULT
                palFrom = currentPalette(now).copyOf()
                palTo = newPal
                palStart = now
            }
        }

        private fun currentPalette(now: Long): IntArray {
            val t = ((now - palStart) / 1200f).coerceIn(0f, 1f)
            for (i in 0 until PaletteExtractor.SIZE) palCur[i] = lerpColor(palFrom[i], palTo[i], t)
            return palCur
        }

        private fun lerpColor(a: Int, b: Int, t: Float): Int {
            val r = (((a shr 16) and 255) * (1 - t) + ((b shr 16) and 255) * t).toInt()
            val g = (((a shr 8) and 255) * (1 - t) + ((b shr 8) and 255) * t).toInt()
            val bl = ((a and 255) * (1 - t) + (b and 255) * t).toInt()
            return Color.rgb(r, g, bl)
        }

        private fun approach(cur: Float, target: Float, step: Float): Float =
            if (cur < target) min(target, cur + step) else max(target, cur - step)

        // ------------------------------------------------------------------ drawing

        private fun drawFrame() {
            if (w == 0 || h == 0) return
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockHardwareCanvas()
                if (canvas != null) render(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (_: Exception) {
                    }
                }
            }
        }

        private fun render(c: Canvas) {
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastFrame).coerceIn(0L, 100L)
            lastFrame = now

            val preview = isPreview
            if (now - lastLockCheck > 400L) {
                locked = preview || (keyguard?.isKeyguardLocked ?: false)
                lastLockCheck = now
            }

            val hasTrack = MusicState.hasTrack
            if (hasTrack) {
                shownTitle = MusicState.title
                shownArtist = MusicState.artist
            } else if (preview && shownTitle.isEmpty()) {
                shownTitle = "Music Wallpaper"
                shownArtist = "Play a song to see it live"
            }

            // Decide whether the music scene should be visible right now.
            val active = MusicState.isPlaying || (keepPaused && hasTrack)
            val wantMusic = preview ||
                (hasTrack && active && (locked || switchMode == Prefs.MODE_LOCK_AND_HOME))
            if (wantMusic) musicHoldUntil = now + switchDelayMs
            val showMusic = wantMusic || now < musicHoldUntil

            val musicTarget = if (showMusic) 1f else 0f
            val homeTarget = if (locked) 0f else 1f
            val step = dt / 600f
            musicAlpha = approach(musicAlpha, musicTarget, step)
            homeAlpha = approach(homeAlpha, homeTarget, step)

            if (musicAlpha < 0.999f) {
                drawBase(c)
                if (homeAlpha > 0.01f) drawHome(c, homeAlpha)
            }
            if (musicAlpha > 0.01f) drawMusic(c, now, musicAlpha)

            animating = musicAlpha > 0.01f || musicAlpha != musicTarget || homeAlpha != homeTarget
        }

        private fun drawBase(c: Canvas) {
            val b = defBmp
            if (b != null) {
                bitmapPaint.alpha = 255
                c.drawBitmap(b, 0f, 0f, bitmapPaint)
            } else {
                bgPaint.alpha = 255
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)
            }
        }

        private fun drawHome(c: Canvas, a: Float) {
            val alpha = (a * 255).toInt()
            val b = homeBlurBmp
            if (b != null) {
                bitmapPaint.alpha = alpha
                dstRect.set(0f, 0f, w.toFloat(), h.toFloat())
                c.drawBitmap(b, null, dstRect, bitmapPaint)
                bitmapPaint.alpha = 255
            } else {
                bgPaint.alpha = alpha
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)
                bgPaint.alpha = 255
            }
            dimPaint.color = Color.argb((a * 0.18f * 255).toInt(), 0, 0, 0)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), dimPaint)
        }

        private fun drawMusic(c: Canvas, now: Long, a: Float) {
            val layer = if (a < 0.999f) {
                c.saveLayerAlpha(0f, 0f, w.toFloat(), h.toFloat(), (a * 255).toInt())
            } else -1

            val pal = currentPalette(now)
            c.drawColor(pal[0])

            // Soft, drifting color blobs (the same idea as the blurred divs in the userscript).
            val t = (now - startTime) / 1000f * (animSpeed / 100f)
            val twoPi = (2 * PI).toFloat()
            for (i in 0 until PaletteExtractor.SIZE) {
                val ang = t * (twoPi / PERIODS[i]) + i * 0.9f
                val cx = w * (BLOB_X[i] + 0.22f * sin(ang))
                val cy = h * (BLOB_Y[i] + 0.10f * cos(ang * 0.8f + 1f))
                val r = h * 0.34f * (1f + 0.18f * sin(ang * 1.3f + i))
                blobPaint.colorFilter = PorterDuffColorFilter(pal[i], PorterDuff.Mode.SRC_IN)
                dstRect.set(cx - r, cy - r, cx + r, cy + r)
                c.drawBitmap(blobBmp, null, dstRect, blobPaint)
            }
            blobPaint.colorFilter = null

            // Dark frost so the text and cover stay readable.
            c.drawColor(Color.argb(frostPct * 255 / 100, 0, 0, 0))

            drawCoverBlock(c, now)

            if (layer != -1) c.restoreToCount(layer)
        }

        private fun drawCoverBlock(c: Canvas, now: Long) {
            val size = w * coverSizePct / 100f
            val textH = if (showText) w * 0.20f else 0f
            val coverBottom = h - h * coverBottomPct / 100f - textH
            val left = (w - size) / 2f
            val top = coverBottom - size
            val radius = size * cornerPct / 100f

            val p = ((now - coverStart) / 500f).coerceIn(0f, 1f)
            val e = 1f - (1f - p).pow(3)
            val scale = 0.94f + 0.06f * e
            val cx = left + size / 2f
            val cy = top + size / 2f
            val half = size / 2f * scale
            coverRect.set(cx - half, cy - half, cx + half, cy + half)

            // Cheap soft shadow: a few stacked translucent rounded rects.
            for (i in 0..5) {
                val grow = i * size * 0.012f
                shadowRect.set(
                    coverRect.left - grow, coverRect.top - grow + size * 0.03f,
                    coverRect.right + grow, coverRect.bottom + grow + size * 0.03f
                )
                shadowPaint.alpha = 20
                c.drawRoundRect(shadowRect, radius + grow, radius + grow, shadowPaint)
            }

            val prev = prevCover
            val cur = curCover
            if (p >= 1f) prevCover = null
            if (p < 1f && prev != null) drawCover(c, prev, coverRect, 255, radius)
            if (cur != null) {
                drawCover(c, cur, coverRect, (255 * e).toInt(), radius)
            } else {
                coverPaint.shader = null
                coverPaint.color = Color.argb(50, 255, 255, 255)
                c.drawRoundRect(coverRect, radius, radius, coverPaint)
                notePaint.textSize = size * 0.4f
                c.drawText("♪", cx, cy + size * 0.14f, notePaint)
            }

            if (showText) {
                val maxW = max(size, w * 0.8f)
                titlePaint.textSize = w * 0.058f
                artistPaint.textSize = w * 0.042f
                val title = TextUtils.ellipsize(shownTitle, titlePaint, maxW, TextUtils.TruncateAt.END).toString()
                val artist = TextUtils.ellipsize(shownArtist, artistPaint, maxW, TextUtils.TruncateAt.END).toString()
                val y1 = coverBottom + w * 0.085f
                c.drawText(title, w / 2f, y1, titlePaint)
                c.drawText(artist, w / 2f, y1 + w * 0.062f, artistPaint)
            }
        }

        private fun drawCover(c: Canvas, layer: CoverLayer, rect: RectF, alpha: Int, radius: Float) {
            val bw = layer.bmp.width.toFloat()
            val bh = layer.bmp.height.toFloat()
            val s = max(rect.width() / bw, rect.height() / bh)
            shaderMatrix.reset()
            shaderMatrix.setScale(s, s)
            shaderMatrix.postTranslate(
                rect.left + (rect.width() - bw * s) / 2f,
                rect.top + (rect.height() - bh * s) / 2f
            )
            layer.shader.setLocalMatrix(shaderMatrix)
            coverPaint.shader = layer.shader
            coverPaint.alpha = alpha
            c.drawRoundRect(rect, radius, radius, coverPaint)
            coverPaint.shader = null
        }

        private fun makeBlobBitmap(): Bitmap {
            val s = 256
            val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = RadialGradient(
                s / 2f, s / 2f, s / 2f,
                intArrayOf(0xE6FFFFFF.toInt(), 0xB3FFFFFF.toInt(), 0x00FFFFFF),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            Canvas(b).drawCircle(s / 2f, s / 2f, s / 2f, p)
            return b
        }
    }

    companion object {
        private val BLOB_X = floatArrayOf(0.20f, 0.80f, 0.50f, 0.15f, 0.85f, 0.35f, 0.65f, 0.50f)
        private val BLOB_Y = floatArrayOf(0.10f, 0.20f, 0.35f, 0.50f, 0.55f, 0.70f, 0.85f, 0.95f)
        private val PERIODS = floatArrayOf(22f, 26f, 30f, 24f, 34f, 28f, 32f, 25f)
    }
}
